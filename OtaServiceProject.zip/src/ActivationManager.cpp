#include "ActivationManager.hpp"
#include <iostream>

bool ActivationManager::SetActive() {
    std::cout << "Notifying MCU to reboot into active system..." << std::endl;
    activated_ = true;
    return true;
}

bool ActivationManager::GetActive(ActiveSta_s *status) {
    status->activated = activated_;
    status->failed = !activated_;
    return true;
}