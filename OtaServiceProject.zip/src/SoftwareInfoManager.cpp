#include "SoftwareInfoManager.hpp"
#include <iostream>

bool SoftwareInfoManager::SetRobotInfo(const RobotInfo_s *info) {
    std::cout << "Saving Robot Info to disk: " << info->serial_number << std::endl;
    return true;
}

bool SoftwareInfoManager::SetOtaMode(otaMode_e mode) {
    std::cout << "Setting OTA mode to " << (mode == otaMode_e::UPDATE_MODE ? "UPDATE" : "NORMAL") << std::endl;
    return true;
}