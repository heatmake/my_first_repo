#include "OtaService.hpp"

bool OtaService::SetRobotInfo(const RobotInfo_s *info) {
    return sw_manager_.SetRobotInfo(info);
}

bool OtaService::SetOtaMode(otaMode_e mode) {
    return sw_manager_.SetOtaMode(mode);
}

bool OtaService::StartUpdate(const char *path) {
    return update_manager_.StartUpdate(path);
}

bool OtaService::GetUpdateStatus(UpdateSta_s *status) {
    return update_manager_.GetUpdateStatus(status);
}

bool OtaService::SetActive() {
    return act_manager_.SetActive();
}

bool OtaService::GetActive(ActiveSta_s *status) {
    return act_manager_.GetActive(status);
}