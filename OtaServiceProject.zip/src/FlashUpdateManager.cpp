#include "FlashUpdateManager.hpp"
#include <chrono>
#include <iostream>

FlashUpdateManager::FlashUpdateManager() : progress_(0), updating_(false) {}

FlashUpdateManager::~FlashUpdateManager() {
    if (update_thread_.joinable()) update_thread_.join();
}

bool FlashUpdateManager::StartUpdate(const char *path) {
    if (updating_) return false;
    updating_ = true;
    progress_ = 0;
    update_thread_ = std::thread(&FlashUpdateManager::UpdateThreadFunc, this);
    return true;
}

void FlashUpdateManager::UpdateThreadFunc() {
    while (progress_ < 100) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        progress_ += 10;
    }
    updating_ = false;
}

bool FlashUpdateManager::GetUpdateStatus(UpdateSta_s *status) {
    status->progress = progress_;
    status->success = (progress_ == 100);
    return true;
}