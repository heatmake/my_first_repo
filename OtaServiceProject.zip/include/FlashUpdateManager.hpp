#pragma once
#include "OtaTypes.hpp"
#include <thread>
#include <atomic>

class FlashUpdateManager {
public:
    FlashUpdateManager();
    ~FlashUpdateManager();
    bool StartUpdate(const char *path);
    bool GetUpdateStatus(UpdateSta_s *status);

private:
    void UpdateThreadFunc();
    std::atomic<int> progress_;
    std::atomic<bool> updating_;
    std::thread update_thread_;
};