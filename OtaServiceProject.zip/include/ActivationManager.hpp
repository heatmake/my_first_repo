#pragma once
#include "OtaTypes.hpp"

class ActivationManager {
public:
    bool SetActive();
    bool GetActive(ActiveSta_s *status);

private:
    bool activated_ = false;
    bool failed_ = false;
};