#pragma once
#include "OtaTypes.hpp"

class SoftwareInfoManager {
public:
    bool SetRobotInfo(const RobotInfo_s *info);
    bool SetOtaMode(otaMode_e mode);
};