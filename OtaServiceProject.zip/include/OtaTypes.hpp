#pragma once

#include <string>

struct RobotInfo_s {
    std::string serial_number;
    std::string software_version;
    std::string vendor_code;
    std::string sw_version;
    std::string hw_version;
};

enum class otaMode_e {
    NORMAL_MODE,
    UPDATE_MODE
};

struct UpdateSta_s {
    int progress; // 0 ~ 100
    bool success;
};

struct ActiveSta_s {
    bool activated;
    bool failed;
};