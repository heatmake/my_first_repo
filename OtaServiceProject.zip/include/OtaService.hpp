#pragma once
#include "OtaTypes.hpp"
#include "SoftwareInfoManager.hpp"
#include "FlashUpdateManager.hpp"
#include "ActivationManager.hpp"

class OtaService {
public:
    bool SetRobotInfo(const RobotInfo_s *info);
    bool SetOtaMode(otaMode_e mode);
    bool StartUpdate(const char *path);
    bool GetUpdateStatus(UpdateSta_s *status);
    bool SetActive();
    bool GetActive(ActiveSta_s *status);

private:
    SoftwareInfoManager sw_manager_;
    FlashUpdateManager update_manager_;
    ActivationManager act_manager_;
};